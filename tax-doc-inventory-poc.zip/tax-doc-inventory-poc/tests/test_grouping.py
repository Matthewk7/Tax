import unittest

from tax_inventory.grouping import group_pages


def page(number, kind, confidence=0.97, text="Form 1099-B", printed=None, year=2025, issuer="Acme Brokerage"):
    return {
        "page_number": number,
        "classification": {"type": kind, "label": kind, "confidence": confidence, "reason": "test"},
        "tax_year": year,
        "issuer": issuer,
        "printed_page_number": printed,
        "text_excerpt": text,
        "is_blank": False,
    }


class GroupingTests(unittest.TestCase):
    def test_continued_1099b_pages_group(self):
        groups = group_pages([
            page(1, "1099_B", text="Form 1099-B Page 1 of 2", printed=1),
            page(2, "1099_B", text="Continued Page 2 of 2", printed=2),
        ])
        self.assertEqual(len(groups), 1)
        self.assertEqual(groups[0]["pages"], [1, 2])

    def test_two_w2s_stay_separate(self):
        groups = group_pages([
            page(1, "W2", text="Form W-2 Wage and Tax Statement", issuer="Employer A"),
            page(2, "W2", text="Form W-2 Wage and Tax Statement", issuer="Employer B"),
        ])
        self.assertEqual(len(groups), 2)


if __name__ == "__main__":
    unittest.main()
