import unittest

from tax_inventory.classifier import classify_page, extract_tax_year


class ClassifierTests(unittest.TestCase):
    def test_w2(self):
        result = classify_page("Form W-2 Wage and Tax Statement 2025 Employer's name")
        self.assertEqual(result["type"], "W2")

    def test_1098_t_precedes_1098(self):
        result = classify_page("Form 1098-T Tuition Statement")
        self.assertEqual(result["type"], "1098_T")

    def test_unknown_is_explicit(self):
        result = classify_page("A random letter with no standard tax form label")
        self.assertEqual(result["type"], "UNKNOWN")

    def test_contextual_tax_year(self):
        self.assertEqual(extract_tax_year("Tax year 2025 issued in 2026"), 2025)


if __name__ == "__main__":
    unittest.main()
