from __future__ import annotations

import io
from typing import Any

import pymupdf
import pytesseract
from PIL import Image, ImageOps

try:
    from pillow_heif import register_heif_opener
    register_heif_opener()
except Exception:
    # HEIC support is optional at runtime; the UI will report a useful error.
    pass

from .classifier import classify_page, extract_issuer, extract_tax_year, page_number_hint

MIN_NATIVE_TEXT_CHARS = 45


def _ocr_pil_image(image: Image.Image) -> str:
    """OCR image locally using the installed Tesseract binary."""
    image = ImageOps.exif_transpose(image).convert("RGB")
    # Tesseract's orientation detection is best-effort and can fail on small
    # images; a failure should not prevent the regular OCR pass.
    try:
        osd = pytesseract.image_to_osd(image)
        import re
        match = re.search(r"Rotate:\s*(\d+)", osd)
        if match and int(match.group(1)) in (90, 180, 270):
            image = image.rotate(-int(match.group(1)), expand=True)
    except Exception:
        pass
    return pytesseract.image_to_string(image, config="--oem 3 --psm 6")


def _page_record(page_number: int, text: str, source_kind: str, ocr_used: bool) -> dict[str, Any]:
    classification = classify_page(text)
    page_hint, page_total_hint = page_number_hint(text)
    stripped = text.strip()
    is_blank = len(stripped) < 8
    warnings = []
    if is_blank:
        warnings.append("Page appears blank or contains too little readable text.")
    elif ocr_used and len(stripped) < 45:
        warnings.append("OCR returned very little text; check image quality and page completeness.")
    if classification["type"] == "UNKNOWN" and not is_blank:
        warnings.append("No configured classification rule matched this page.")
    return {
        "page_number": page_number,
        "source_kind": source_kind,
        "ocr_used": ocr_used,
        "text_chars": len(stripped),
        "text_excerpt": stripped[:900],
        "classification": classification,
        "tax_year": extract_tax_year(text),
        "issuer": extract_issuer(text),
        "printed_page_number": page_hint,
        "printed_page_total": page_total_hint,
        "is_blank": is_blank,
        "warnings": warnings,
    }


def process_pdf(data: bytes) -> list[dict[str, Any]]:
    records = []
    try:
        document = pymupdf.open(stream=data, filetype="pdf")
    except Exception as exc:
        raise ValueError(f"Could not open PDF: {exc}") from exc

    if document.needs_pass:
        document.close()
        raise ValueError("This PDF is password-protected. Remove the password locally before testing.")

    try:
        for index, page in enumerate(document):
            text = page.get_text("text") or ""
            ocr_used = False
            if len(text.strip()) < MIN_NATIVE_TEXT_CHARS:
                pix = page.get_pixmap(dpi=250, alpha=False)
                image = Image.open(io.BytesIO(pix.tobytes("png")))
                try:
                    text = _ocr_pil_image(image)
                    ocr_used = True
                except pytesseract.pytesseract.TesseractNotFoundError as exc:
                    raise RuntimeError(
                        "Tesseract was not found. Install the Tesseract OCR application and ensure it is on PATH."
                    ) from exc
            records.append(_page_record(index + 1, text, "pdf", ocr_used))
    finally:
        document.close()
    return records


def process_image(data: bytes) -> list[dict[str, Any]]:
    try:
        image = Image.open(io.BytesIO(data))
        image.load()
    except Exception as exc:
        raise ValueError(
            "Could not open image. Supported inputs are JPEG, PNG, TIFF, and HEIC/HEIF (with pillow-heif installed)."
        ) from exc
    try:
        text = _ocr_pil_image(image)
    except pytesseract.pytesseract.TesseractNotFoundError as exc:
        raise RuntimeError(
            "Tesseract was not found. Install the Tesseract OCR application and ensure it is on PATH."
        ) from exc
    return [_page_record(1, text, "image", True)]


def process_upload(filename: str, data: bytes) -> list[dict[str, Any]]:
    suffix = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    if suffix == "pdf":
        return process_pdf(data)
    if suffix in {"jpg", "jpeg", "png", "tif", "tiff", "heic", "heif", "webp"}:
        return process_image(data)
    raise ValueError("Unsupported file type. Upload one PDF or one image (JPG, PNG, TIFF, HEIC/HEIF, or WEBP).")
