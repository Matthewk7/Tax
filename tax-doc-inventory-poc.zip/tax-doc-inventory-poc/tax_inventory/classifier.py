"""Transparent, rule-based tax-document classifier.

Scores are heuristic rule-match scores, not statistically calibrated probabilities.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Rule:
    code: str
    label: str
    patterns: tuple[str, ...]
    base_score: float = 0.88


RULES: tuple[Rule, ...] = (
    Rule("W2", "W-2", (r"\bform\s+w[\s-]?2\b", r"\bwage[s]?\s+and\s+tax\s+statement\b"), 0.98),
    Rule("1099_INT", "1099-INT", (r"\bform\s+1099[\s-]?int\b", r"\binterest\s+income\b"), 0.97),
    Rule("1099_DIV", "1099-DIV", (r"\bform\s+1099[\s-]?div\b", r"\bdividends\s+and\s+distributions\b"), 0.97),
    Rule("1099_NEC", "1099-NEC", (r"\bform\s+1099[\s-]?nec\b", r"\bnonemployee\s+compensation\b"), 0.97),
    Rule("1099_MISC", "1099-MISC", (r"\bform\s+1099[\s-]?misc\b", r"\bmiscellaneous\s+information\b"), 0.96),
    Rule("1099_K", "1099-K", (r"\bform\s+1099[\s-]?k\b", r"\bpayment\s+card\s+and\s+third.party\s+network\s+transactions\b"), 0.96),
    Rule("1099_B", "1099-B / Brokerage statement", (r"\bform\s+1099[\s-]?b\b", r"\bproceeds\s+from\s+broker\s+and\s+barter\s+exchange\s+transactions\b"), 0.97),
    Rule("1098_T", "1098-T", (r"\bform\s+1098[\s-]?t\b", r"\btuition\s+statement\b"), 0.96),
    Rule("1098", "1098 Mortgage Interest Statement", (r"\bform\s+1098\b", r"\bmortgage\s+interest\s+statement\b"), 0.95),
    Rule("1099_R", "1099-R", (r"\bform\s+1099[\s-]?r\b", r"\bdistributions\s+from\s+pensions\b"), 0.96),
    Rule("SCHEDULE_K1", "Schedule K-1", (r"\bschedule\s+k[\s-]?1\b", r"\bpartner.s\s+share\s+of\s+income\b", r"\bshareholder.s\s+share\s+of\s+income\b"), 0.94),
    Rule("1095_A", "1095-A", (r"\bform\s+1095[\s-]?a\b", r"\bhealth\s+insurance\s+marketplace\s+statement\b"), 0.96),
    Rule("PROPERTY_TAX", "Property tax statement", (r"\bproperty\s+tax\s+statement\b", r"\breal\s+estate\s+tax\s+bill\b", r"\bcounty\s+tax\s+collector\b"), 0.83),
    Rule("CHARITABLE_CONTRIBUTIONS", "Charitable contributions / donation summary", (r"\bcharitable\s+contribution[s]?\b", r"\bdonation\s+(?:receipt|summary|statement)\b", r"\bnoncash\s+charitable\s+contributions\b"), 0.82),
    Rule("BROKERAGE_STATEMENT", "Brokerage statement (not specifically identified as 1099-B)", (r"\bbrokerage\s+account\s+statement\b", r"\binvestment\s+account\s+statement\b"), 0.82),
)


def normalize_text(text: str) -> str:
    text = text.replace("\u00a0", " ")
    text = text.replace("—", "-").replace("–", "-")
    return re.sub(r"[ \t]+", " ", text).lower()


def classify_page(text: str) -> dict:
    """Return a conservative type classification based on visible text only."""
    normalized = normalize_text(text)
    candidates: list[tuple[float, Rule, list[str]]] = []
    for rule in RULES:
        matched = [pattern for pattern in rule.patterns if re.search(pattern, normalized, re.I)]
        if not matched:
            continue
        # A form-number/title match is stronger than a generic supporting phrase.
        score = rule.base_score
        if len(matched) > 1:
            score = min(0.995, score + 0.02)
        if rule.code in {"PROPERTY_TAX", "CHARITABLE_CONTRIBUTIONS", "BROKERAGE_STATEMENT"}:
            score = min(score, 0.90)
        candidates.append((score, rule, matched))

    if not candidates:
        return {
            "type": "UNKNOWN",
            "label": "Unidentified / other",
            "confidence": 0.0,
            "reason": "No configured document-identification rule matched the extracted text.",
        }

    # Prefer the most specific rule when scores tie (e.g., 1098-T over 1098).
    candidates.sort(key=lambda item: (item[0], len(item[1].code)), reverse=True)
    score, rule, matched = candidates[0]
    return {
        "type": rule.code,
        "label": rule.label,
        "confidence": round(score, 3),
        "reason": "Matched text pattern(s): " + ", ".join(matched),
    }


def extract_tax_year(text: str) -> Optional[int]:
    """Extract a likely tax year; intentionally returns None when ambiguous."""
    normalized = normalize_text(text)
    contextual = re.findall(
        r"(?:tax\s+year|for\s+the\s+year|calendar\s+year|year\s+ended|tax\s+period)\D{0,18}(20\d{2})",
        normalized,
        re.I,
    )
    if contextual:
        years = [int(y) for y in contextual]
        return max(set(years), key=years.count)

    # Form-year headings are commonly near the top. Avoid deriving a year from
    # arbitrary account numbers or dates; require a plausible four-digit year.
    years = [int(y) for y in re.findall(r"\b(20(?:1[5-9]|2[0-9]))\b", normalized)]
    if not years:
        return None
    counts = {year: years.count(year) for year in set(years)}
    best = max(counts, key=counts.get)
    # If multiple years are equally frequent, leave it unknown rather than guess.
    if list(counts.values()).count(counts[best]) > 1:
        return None
    return best


def extract_issuer(text: str) -> Optional[str]:
    """Best-effort issuer extraction from explicitly labeled fields.

    This intentionally returns None rather than guessing from arbitrary names
    on a form (which may be the taxpayer or recipient).
    """
    lines = [re.sub(r"\s+", " ", line).strip(" :|\t") for line in text.splitlines()]
    labels = (
        "employer's name", "employer name", "payer's name", "payer name",
        "lender's name", "lender name", "filer's name", "filer name",
        "financial institution", "brokerage firm",
    )
    placeholder_terms = (
        "address", "city or town", "state or province", "country", "zip code",
        "employee's name", "recipient's name", "social security", "account number",
    )
    for index, line in enumerate(lines):
        low = line.lower()
        for label in labels:
            position = low.find(label)
            if position < 0:
                continue
            tail = line[position + len(label):].strip(" :,-")
            if tail and not any(term in tail.lower() for term in placeholder_terms) and len(tail) >= 3:
                return tail[:100]
            for candidate in lines[index + 1:index + 3]:
                candidate_low = candidate.lower()
                if not candidate or any(term in candidate_low for term in placeholder_terms):
                    continue
                if any(other in candidate_low for other in labels):
                    continue
                if len(candidate) >= 3 and not re.fullmatch(r"[0-9 .,/()-]+", candidate):
                    return candidate[:100]
    return None


def page_number_hint(text: str) -> tuple[Optional[int], Optional[int]]:
    match = re.search(r"\bpage\s+(\d{1,3})\s+(?:of|/)\s+(\d{1,3})\b", text, re.I)
    if match:
        return int(match.group(1)), int(match.group(2))
    return None, None
