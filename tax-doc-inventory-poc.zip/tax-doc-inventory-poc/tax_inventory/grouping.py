from __future__ import annotations

import re
import uuid
from typing import Any

MULTI_PAGE_TYPES = {"1099_B", "BROKERAGE_STATEMENT", "SCHEDULE_K1"}
CONTINUATION_TERMS = (
    "continued", "continuation", "see next page", "page follows", "carry over",
    "carryover", "additional information", "transaction detail",
)


def _has_continuation_evidence(page: dict[str, Any]) -> bool:
    excerpt = (page.get("text_excerpt") or "").lower()
    printed_page = page.get("printed_page_number")
    if printed_page and printed_page > 1:
        return True
    return any(term in excerpt for term in CONTINUATION_TERMS)


def group_pages(pages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Conservative adjacent-page grouping; uncertain pages remain reviewable.

    This POC does not perform visual layout matching or semantic statement
    reconciliation. It only joins adjacent pages when continuation evidence
    supports the decision.
    """
    groups: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None

    def new_group(page: dict[str, Any], group_type: str | None = None, inherited: bool = False) -> dict[str, Any]:
        classification = page["classification"]
        return {
            "document_id": str(uuid.uuid4()),
            "type": group_type or classification["type"],
            "label": classification["label"] if not inherited else "Unidentified continuation (review)",
            "pages": [page["page_number"]],
            "tax_year": page.get("tax_year"),
            "issuer": page.get("issuer"),
            "confidence": classification["confidence"] if not inherited else 0.35,
            "needs_review": inherited or classification["type"] == "UNKNOWN" or classification["confidence"] < 0.85,
            "review_reasons": (["Page type was inferred from the preceding document; verify grouping."] if inherited else []),
            "page_classifications": [classification["type"]],
        }

    for page in pages:
        ctype = page["classification"]["type"]
        if page.get("is_blank"):
            # Blank pages are retained in page-level results, but aren't counted
            # as tax documents. They are not silently attached to either side.
            current = None
            continue

        if current is None:
            current = new_group(page)
            groups.append(current)
            continue

        same_type = ctype != "UNKNOWN" and ctype == current["type"]
        same_tax_year = not page.get("tax_year") or not current.get("tax_year") or page.get("tax_year") == current.get("tax_year")
        same_issuer = not page.get("issuer") or not current.get("issuer") or page.get("issuer") == current.get("issuer")
        continuation = _has_continuation_evidence(page)

        if ctype == "UNKNOWN" and continuation:
            current["pages"].append(page["page_number"])
            current["page_classifications"].append("UNKNOWN_CONTINUATION")
            current["needs_review"] = True
            current["review_reasons"].append(
                f"Page {page['page_number']} was attached based on continuation evidence but its document type was not identified."
            )
            current["confidence"] = min(current["confidence"], 0.65)
            continue

        if same_type and same_tax_year and same_issuer and continuation and (
            current["type"] in MULTI_PAGE_TYPES or page.get("printed_page_number", 1) > 1
        ):
            current["pages"].append(page["page_number"])
            current["page_classifications"].append(ctype)
            current["confidence"] = min(current["confidence"], page["classification"]["confidence"])
            if page.get("tax_year") and not current.get("tax_year"):
                current["tax_year"] = page["tax_year"]
            if page.get("issuer") and not current.get("issuer"):
                current["issuer"] = page["issuer"]
            continue

        current = new_group(page)
        groups.append(current)

    # Deduplicate review reasons while retaining order.
    for group in groups:
        group["review_reasons"] = list(dict.fromkeys(group["review_reasons"]))
    return groups
